import sys
import os

# Add your project directory to the Python path
path = '/home/vasylfalyovskij/library_api'
if path not in sys.path:
    sys.path.append(path)

# Import your FastAPI application
from main import app

# Create a WSGI application
application = app 